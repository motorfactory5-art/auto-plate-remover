import streamlit as st
import cv2
import numpy as np
from PIL import Image

st.title("🚗 Auto Plate Remover (Online Version)")
st.write("Upload une image de voiture et l'application masquera automatiquement la plaque d'immatriculation.")

uploaded_file = st.file_uploader("Choisissez une image", type=["jpg", "jpeg", "png"])

def detect_and_blur_plate(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    plate_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_russian_plate_number.xml")
    plates = plate_cascade.detectMultiScale(gray, 1.1, 4)
    for (x, y, w, h) in plates:
        roi = img[y:y+h, x:x+w]
        roi = cv2.GaussianBlur(roi, (51, 51), 30)
        img[y:y+h, x:x+w] = roi
    return img

if uploaded_file is not None:
    img = Image.open(uploaded_file)
    img_cv = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
    result_img = detect_and_blur_plate(img_cv)
    st.image(cv2.cvtColor(result_img, cv2.COLOR_BGR2RGB), caption="Résultat", use_column_width=True)
